const books = [
  { id: 1 }
]

module.exports = books
